import React, { useState, useEffect, useRef } from 'react';
import { 
  Calculator, 
  Shield, 
  Phone, 
  FileText, 
  Brain, 
  Users, 
  Heart, 
  Scale, 
  Lock, 
  Camera, 
  Mic, 
  MapPin, 
  Send, 
  AlertTriangle,
  Menu,
  X,
  Plus,
  Eye,
  EyeOff,
  Image,
  BookOpen,
  Settings,
  UserPlus,
  Wifi,
  WifiOff,
  Cloud,
  PhoneCall,
  Video,
  Navigation,
  CheckCircle,
  XCircle,
  VolumeX,
  Smartphone
} from 'lucide-react';

const SAHAYAK = () => {
  const [currentView, setCurrentView] = useState('disguised');
  const [disguiseMode, setDisguiseMode] = useState('calculator'); // calculator, gallery, notes
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [trustedContacts, setTrustedContacts] = useState([
    { id: 1, name: 'Mom', phone: '+91-9876543210', relation: 'Mother' },
    { id: 2, name: 'Sister', phone: '+91-9876543211', relation: 'Sister' }
  ]);
  const [incidents, setIncidents] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [sosActive, setSosActive] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [calculatorDisplay, setCalculatorDisplay] = useState('0');
  const [hiddenPin, setHiddenPin] = useState('');
  const [showPinInput, setShowPinInput] = useState(false);
  const [distressLevel, setDistressLevel] = useState(0);
  const [isOnline, setIsOnline] = useState(true);
  const [liveStreaming, setLiveStreaming] = useState(false);
  const [gpsTracking, setGpsTracking] = useState(false);
  const [fakeCallActive, setFakeCallActive] = useState(false);
  const [lastCheckIn, setLastCheckIn] = useState(null);
  const [safetyPlan, setSafetyPlan] = useState({
    sosActions: ['call', 'sms', 'video', 'location'],
    priorityContact: 1,
    autoCallPolice: true,
    silentMode: false
  });
  const [currentLocation, setCurrentLocation] = useState({ lat: 28.6139, lng: 77.2090 });
  const [voiceEmotion, setVoiceEmotion] = useState('normal');
  const [shakeDetection, setShakeDetection] = useState(0);
  const [highRiskZoneAlert, setHighRiskZoneAlert] = useState(false);
  
  const [newIncident, setNewIncident] = useState({
    title: '',
    description: '',
    date: '',
    severity: 'low',
    evidence: []
  });

  const [newContact, setNewContact] = useState({
    name: '',
    phone: '',
    relation: ''
  });

  const monitoringRef = useRef(null);
  const checkInRef = useRef(null);
  const shakeTimeoutRef = useRef(null);

  // Enhanced AI monitoring with voice emotion and shake detection
  useEffect(() => {
    if (isAuthenticated) {
      monitoringRef.current = setInterval(() => {
        // Simulate various AI detections
        const randomDistress = Math.random() * 100;
        const emotions = ['normal', 'stress', 'fear', 'anger'];
        const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
        const randomShake = Math.random() * 10;
        
        setDistressLevel(randomDistress);
        setVoiceEmotion(randomEmotion);
        setShakeDetection(randomShake);
        
        // High-risk zone detection (simulate)
        if (Math.random() > 0.95) {
          setHighRiskZoneAlert(true);
          setTimeout(() => setHighRiskZoneAlert(false), 5000);
        }
        
        // Auto-trigger SOS based on multiple factors
        if (randomDistress > 85 || randomEmotion === 'fear' || randomShake > 8) {
          handleEmergencySOS(true, `AI Detection: ${randomEmotion} emotion, distress ${Math.round(randomDistress)}%`);
        }
      }, 3000);

      // Check-in prompts every 2 hours (demo: every 20 seconds)
      checkInRef.current = setInterval(() => {
        if (!sosActive && Math.random() > 0.8) {
          showCheckInPrompt();
        }
      }, 20000);
    }

    return () => {
      if (monitoringRef.current) clearInterval(monitoringRef.current);
      if (checkInRef.current) clearInterval(checkInRef.current);
    };
  }, [isAuthenticated]);

  // Network status detection
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Double tap to hide app
  useEffect(() => {
    let tapCount = 0;
    let tapTimeout;

    const handleDoubleClick = () => {
      tapCount++;
      if (tapCount === 1) {
        tapTimeout = setTimeout(() => {
          tapCount = 0;
        }, 300);
      } else if (tapCount === 2) {
        clearTimeout(tapTimeout);
        tapCount = 0;
        panicExit();
      }
    };

    document.addEventListener('dblclick', handleDoubleClick);
    return () => document.removeEventListener('dblclick', handleDoubleClick);
  }, []);

  const panicExit = () => {
    setCurrentView('disguised');
    setIsAuthenticated(false);
    setShowMenu(false);
    // In real app, this could minimize or switch to another app
  };

  const showCheckInPrompt = () => {
    const response = confirm("SAHAYAK Check-in: Are you safe right now?");
    const checkIn = {
      timestamp: new Date().toISOString(),
      status: response ? 'safe' : 'not_safe',
      location: currentLocation
    };
    setLastCheckIn(checkIn);
    
    if (!response) {
      // If user indicates they're not safe, trigger emergency protocols
      handleEmergencySOS(true, 'User reported unsafe during check-in');
    }
  };

  const handleCalculatorInput = (value) => {
    if (value === 'C') {
      setCalculatorDisplay('0');
      setHiddenPin('');
    } else if (value === '=') {
      if (calculatorDisplay === '911' || hiddenPin.includes('911')) {
        setShowPinInput(true);
      } else {
        try {
          const result = eval(calculatorDisplay).toString();
          setCalculatorDisplay(result);
        } catch {
          setCalculatorDisplay('Error');
        }
      }
    } else {
      const newDisplay = calculatorDisplay === '0' ? value : calculatorDisplay + value;
      setCalculatorDisplay(newDisplay);
      setHiddenPin(prev => prev + value);
    }
  };

  const authenticate = (pin) => {
    if (pin === '1234') {
      setIsAuthenticated(true);
      setCurrentView('dashboard');
      setShowPinInput(false);
    }
  };

  const handleEmergencySOS = async (autoTriggered = false, trigger_reason = '') => {
    setSosActive(true);
    
    const emergencyData = {
      location: currentLocation,
      timestamp: new Date().toISOString(),
      autoTriggered,
      trigger_reason,
      distressLevel,
      voiceEmotion,
      safetyPlan
    };

    // Start GPS tracking
    setGpsTracking(true);
    
    // Execute safety plan actions
    if (safetyPlan.sosActions.includes('video')) {
      setLiveStreaming(true);
    }
    
    if (safetyPlan.sosActions.includes('call') && safetyPlan.autoCallPolice) {
      await simulateEmergencyCall();
    }
    
    if (safetyPlan.sosActions.includes('sms')) {
      await sendEmergencySMS(emergencyData);
    }
    
    // Notify trusted contacts
    notifyTrustedContacts(emergencyData);
    
    setTimeout(() => {
      setSosActive(false);
      setLiveStreaming(false);
      alert(`Emergency Alert Sent!\nLocation: ${emergencyData.location.lat}, ${emergencyData.location.lng}\n${autoTriggered ? `Auto-triggered: ${trigger_reason}` : 'Manually triggered'}\nTrusted contacts notified: ${trustedContacts.length}`);
    }, 5000);
  };

  const simulateEmergencyCall = async () => {
    // Simulate calling nearest police station or 112
    return new Promise(resolve => {
      console.log('Calling emergency services: 112');
      setTimeout(resolve, 1000);
    });
  };

  const sendEmergencySMS = async (data) => {
    if (isOnline) {
      // Online: Send via internet
      console.log('Sending emergency data via internet:', data);
    } else {
      // Offline: Send SMS with GPS coordinates
      console.log('Offline mode: Sending SMS with location:', data.location);
      // In real app: use native SMS API
    }
  };

  const notifyTrustedContacts = (data) => {
    trustedContacts.forEach(contact => {
      console.log(`Notifying ${contact.name} (${contact.phone}):`, data);
      // In real app: send SMS/call/push notification
    });
  };

  const startFakeCall = () => {
    setFakeCallActive(true);
    // Simulate incoming call interface
    setTimeout(() => {
      setFakeCallActive(false);
    }, 30000); // 30 second fake call
  };

  const addTrustedContact = () => {
    if (newContact.name && newContact.phone) {
      setTrustedContacts(prev => [...prev, {
        id: Date.now(),
        ...newContact
      }]);
      setNewContact({ name: '', phone: '', relation: '' });
    }
  };

  const addIncident = () => {
    const incident = {
      ...newIncident,
      id: Date.now(),
      timestamp: new Date().toISOString(),
      location: currentLocation,
      autoBackup: isOnline
    };
    
    setIncidents(prev => [...prev, incident]);
    
    // Auto-backup to cloud if online
    if (isOnline) {
      console.log('Auto-backing up incident to cloud:', incident);
    }
    
    setNewIncident({
      title: '',
      description: '',
      date: '',
      severity: 'low',
      evidence: []
    });
  };

  // Disguised interfaces
  const DisguisedCalculator = () => (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-sm mx-auto bg-black rounded-lg p-4">
        <div className="bg-gray-800 p-4 mb-4 rounded text-right text-white text-2xl">
          {calculatorDisplay}
        </div>
        
        <div className="grid grid-cols-4 gap-2">
          {['C', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '='].map((btn) => (
            <button
              key={btn}
              onClick={() => handleCalculatorInput(btn)}
              className={`p-4 rounded text-white font-semibold ${
                ['÷', '×', '-', '+', '='].includes(btn) 
                  ? 'bg-orange-500 hover:bg-orange-600' 
                  : ['C', '±', '%'].includes(btn)
                  ? 'bg-gray-600 hover:bg-gray-700'
                  : 'bg-gray-700 hover:bg-gray-600'
              }`}
            >
              {btn}
            </button>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between">
          <button
            onClick={() => setDisguiseMode('gallery')}
            className="text-gray-400 text-xs hover:text-white"
          >
            Gallery
          </button>
          <button
            onClick={() => setDisguiseMode('notes')}
            className="text-gray-400 text-xs hover:text-white"
          >
            Notes
          </button>
          <p className="text-gray-500 text-xs">Enter 911 for access</p>
        </div>
      </div>
    </div>
  );

  const DisguisedGallery = () => (
    <div className="min-h-screen bg-black p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-white text-xl font-bold">Gallery</h1>
        <button
          onClick={() => setDisguiseMode('calculator')}
          className="text-gray-400"
        >
          <Calculator size={24} />
        </button>
      </div>
      
      <div className="grid grid-cols-3 gap-2">
        {Array.from({ length: 12 }, (_, i) => (
          <div
            key={i}
            className="aspect-square bg-gray-800 rounded cursor-pointer"
            onClick={() => i === 8 && setShowPinInput(true)} // Hidden trigger on 9th image
          >
            <Image className="w-full h-full text-gray-600 p-4" />
          </div>
        ))}
      </div>
    </div>
  );

  const DisguisedNotes = () => (
    <div className="min-h-screen bg-white p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-gray-800 text-xl font-bold">Notes</h1>
        <button
          onClick={() => setDisguiseMode('calculator')}
          className="text-gray-600"
        >
          <Calculator size={24} />
        </button>
      </div>
      
      <div className="space-y-3">
        <div className="p-3 bg-yellow-100 rounded">
          <h3 className="font-semibold">Shopping List</h3>
          <p className="text-sm text-gray-600">Milk, Bread, Eggs...</p>
        </div>
        <div
          className="p-3 bg-blue-100 rounded cursor-pointer"
          onClick={() => setShowPinInput(true)} // Hidden trigger
        >
          <h3 className="font-semibold">Emergency Contacts</h3>
          <p className="text-sm text-gray-600">Important numbers to remember</p>
        </div>
        <div className="p-3 bg-green-100 rounded">
          <h3 className="font-semibold">Meeting Notes</h3>
          <p className="text-sm text-gray-600">Project discussion points...</p>
        </div>
      </div>
    </div>
  );

  const FakeCallScreen = () => (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col">
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-32 h-32 bg-gray-700 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Phone size={48} />
          </div>
          <h2 className="text-2xl font-bold mb-2">Mom</h2>
          <p className="text-gray-400 mb-8">Calling...</p>
          <div className="w-16 h-16 bg-red-500 rounded-full mx-auto animate-pulse"></div>
        </div>
      </div>
      
      <div className="p-8 flex justify-center space-x-8">
        <button
          onClick={() => setFakeCallActive(false)}
          className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center"
        >
          <Phone className="text-white transform rotate-45" />
        </button>
      </div>
    </div>
  );

  const PinInput = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg">
        <h3 className="text-lg font-semibold mb-4">Enter Security PIN</h3>
        <input
          type="password"
          className="w-full p-2 border rounded mb-4"
          placeholder="Enter PIN (Demo: 1234)"
          onChange={(e) => authenticate(e.target.value)}
        />
        <button
          onClick={() => setShowPinInput(false)}
          className="w-full bg-gray-300 p-2 rounded"
        >
          Cancel
        </button>
      </div>
    </div>
  );

  const Dashboard = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-pink-600 p-4">
      <div className="max-w-md mx-auto">
        {/* Header with status indicators */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-white text-2xl font-bold">SAHAYAK</h1>
            <div className="flex items-center space-x-2">
              <p className="text-purple-200">Stay Safe & Protected</p>
              {!isOnline && <WifiOff size={16} className="text-red-300" />}
              {gpsTracking && <Navigation size={16} className="text-green-300 animate-pulse" />}
            </div>
          </div>
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="text-white p-2"
          >
            <Menu />
          </button>
        </div>

        {/* High-risk zone alert */}
        {highRiskZoneAlert && (
          <div className="bg-red-500 bg-opacity-90 p-3 rounded-lg mb-4 text-white animate-pulse">
            <div className="flex items-center">
              <AlertTriangle className="mr-2" />
              <span className="font-semibold">High-risk zone detected! Stay alert.</span>
            </div>
          </div>
        )}

        {/* Enhanced AI Monitoring Status */}
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Brain className="text-white mr-2" />
              <span className="text-white font-semibold">AI Protection</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
              distressLevel < 30 ? 'bg-green-500 text-white' :
              distressLevel < 70 ? 'bg-yellow-500 text-black' :
              'bg-red-500 text-white'
            }`}>
              {distressLevel < 30 ? 'Safe' : distressLevel < 70 ? 'Alert' : 'High Risk'}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-white text-center">
              <p className="opacity-70">Voice</p>
              <p className="font-semibold capitalize">{voiceEmotion}</p>
            </div>
            <div className="text-white text-center">
              <p className="opacity-70">Motion</p>
              <p className="font-semibold">{shakeDetection > 5 ? 'Active' : 'Normal'}</p>
            </div>
            <div className="text-white text-center">
              <p className="opacity-70">Location</p>
              <p className="font-semibold">{isOnline ? 'Tracked' : 'Offline'}</p>
            </div>
          </div>
        </div>

        {/* Last Check-in Status */}
        {lastCheckIn && (
          <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-3 mb-4">
            <div className="flex items-center justify-between text-white text-sm">
              <span>Last check-in:</span>
              <div className="flex items-center">
                {lastCheckIn.status === 'safe' ? 
                  <CheckCircle size={16} className="text-green-300 mr-1" /> :
                  <XCircle size={16} className="text-red-300 mr-1" />
                }
                <span>{new Date(lastCheckIn.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        )}

        {/* Emergency SOS Button */}
        <div className="mb-4">
          <button
            onClick={() => handleEmergencySOS()}
            className={`w-full p-6 rounded-full text-white font-bold text-xl transition-all duration-300 ${
              sosActive 
                ? 'bg-red-600 animate-pulse shadow-lg shadow-red-500/50' 
                : 'bg-red-500 hover:bg-red-600 shadow-lg'
            }`}
            disabled={sosActive}
          >
            {sosActive ? (
              <div className="flex items-center justify-center">
                <AlertTriangle className="mr-2 animate-spin" />
                {liveStreaming ? 'LIVE STREAMING...' : 'SENDING ALERT...'}
              </div>
            ) : (
              <>
                <Shield size={24} className="inline mr-2" />
                {safetyPlan.silentMode ? 'SILENT SOS' : 'EMERGENCY SOS'}
              </>
            )}
          </button>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <button
            onClick={() => setCurrentView('incidents')}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-4 rounded-lg text-white"
          >
            <FileText className="mb-2 mx-auto" />
            <p className="text-sm font-semibold">Evidence Vault</p>
          </button>
          
          <button
            onClick={() => setCurrentView('contacts')}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-4 rounded-lg text-white"
          >
            <UserPlus className="mb-2 mx-auto" />
            <p className="text-sm font-semibold">Trusted Contacts</p>
          </button>
          
          <button
            onClick={startFakeCall}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-4 rounded-lg text-white"
          >
            <PhoneCall className="mb-2 mx-auto" />
            <p className="text-sm font-semibold">Fake Call</p>
          </button>
          
          <button
            onClick={() => setCurrentView('resources')}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-4 rounded-lg text-white"
          >
            <Heart className="mb-2 mx-auto" />
            <p className="text-sm font-semibold">Get Help</p>
          </button>
        </div>

        {/* Secondary Actions */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setCurrentView('community')}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-3 rounded-lg text-white text-center"
          >
            <Users className="mb-1 mx-auto" size={20} />
            <p className="text-xs">Community</p>
          </button>
          
          <button
            onClick={() => setIsRecording(!isRecording)}
            className={`bg-white bg-opacity-20 backdrop-blur-lg p-3 rounded-lg text-white text-center ${
              isRecording ? 'bg-red-500 bg-opacity-50' : ''
            }`}
          >
            <Mic className="mb-1 mx-auto" size={20} />
            <p className="text-xs">{isRecording ? 'Recording...' : 'Record'}</p>
          </button>

          <button
            onClick={() => setCurrentView('settings')}
            className="bg-white bg-opacity-20 backdrop-blur-lg p-3 rounded-lg text-white text-center"
          >
            <Settings className="mb-1 mx-auto" size={20} />
            <p className="text-xs">Safety Plan</p>
          </button>
        </div>
      </div>
    </div>
  );

  const TrustedContacts = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="mr-4 p-2 text-gray-600"
          >
            <X />
          </button>
          <h2 className="text-xl font-bold">Trusted Contacts</h2>
        </div>

        {/* Add New Contact */}
        <div className="bg-white rounded-lg p-4 mb-4">
          <h3 className="font-semibold mb-3">Add Trusted Contact</h3>
          <input
            type="text"
            placeholder="Name"
            value={newContact.name}
            onChange={(e) => setNewContact(prev => ({...prev, name: e.target.value}))}
            className="w-full p-2 border rounded mb-2"
          />
          <input
            type="tel"
            placeholder="Phone Number"
            value={newContact.phone}
            onChange={(e) => setNewContact(prev => ({...prev, phone: e.target.value}))}
            className="w-full p-2 border rounded mb-2"
          />
          <input
            type="text"
            placeholder="Relation (e.g., Sister, Friend)"
            value={newContact.relation}
            onChange={(e) => setNewContact(prev => ({...prev, relation: e.target.value}))}
            className="w-full p-2 border rounded mb-3"
          />
          <button
            onClick={addTrustedContact}
            className="w-full bg-purple-600 text-white p-2 rounded font-semibold"
          >
            Add Contact
          </button>
        </div>

        {/* Contacts List */}
        <div className="space-y-3">
          {trustedContacts.map(contact => (
            <div key={contact.id} className="bg-white rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold">{contact.name}</h3>
                  <p className="text-gray-600 text-sm">{contact.phone}</p>
                  <p className="text-gray-500 text-xs">{contact.relation}</p>
                </div>
                <div className="flex space-x-2">
                  <button className="p-2 text-green-600 bg-green-50 rounded">
                    <Phone size={16} />
                  </button>
                  <button className="p-2 text-blue-600 bg-blue-50 rounded">
                    <Send size={16} />
                  </button>
                </div>
              </div>
              {contact.id === safetyPlan.priorityContact && (
                <div className="mt-2 text-xs text-purple-600 font-semibold">
                  Priority Contact
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const SafetySettings = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="mr-4 p-2 text-gray-600"
          >
            <X />
          </button>
          <h2 className="text-xl font-bold">Safety Plan Settings</h2>
        </div>

        <div className="space-y-4">
          {/* SOS Actions */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-semibold mb-3">Emergency Actions</h3>
            <div className="space-y-2">
              {[
                { key: 'call', label: 'Auto-call emergency services', icon: Phone },
                { key: 'sms', label: 'Send SMS alerts', icon: Send },
                { key: 'video', label: 'Start live video stream', icon: Video },
                { key: 'location', label: 'Share GPS location', icon: MapPin }
              ].map(action => (
                <label key={action.key} className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={safetyPlan.sosActions.includes(action.key)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSafetyPlan(prev => ({
                          ...prev,
                          sosActions: [...prev.sosActions, action.key]
                        }));
                      } else {
                        setSafetyPlan(prev => ({
                          ...prev,
                          sosActions: prev.sosActions.filter(a => a !== action.key)
                        }));
                      }
                    }}
                    className="w-4 h-4"
                  />
                  <action.icon size={16} className="text-gray-600" />
                  <span className="text-sm">{action.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Priority Contact */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-semibold mb-3">Priority Contact</h3>
            <select
              value={safetyPlan.priorityContact}
              onChange={(e) => setSafetyPlan(prev => ({
                ...prev,
                priorityContact: parseInt(e.target.value)
              }))}
              className="w-full p-2 border rounded"
            >
              {trustedContacts.map(contact => (
                <option key={contact.id} value={contact.id}>
                  {contact.name} ({contact.relation})
                </option>
              ))}
            </select>
          </div>

          {/* Silent Mode */}
          <div className="bg-white rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold">Silent SOS Mode</h3>
                <p className="text-sm text-gray-600">Triggers alert without visible indication</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyPlan.silentMode}
                  onChange={(e) => setSafetyPlan(prev => ({
                    ...prev,
                    silentMode: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>
          </div>

          {/* Auto-call Police */}
          <div className="bg-white rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold">Auto-call Police</h3>
                <p className="text-sm text-gray-600">Automatically call 112 during SOS</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyPlan.autoCallPolice}
                  onChange={(e) => setSafetyPlan(prev => ({
                    ...prev,
                    autoCallPolice: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const IncidentLogger = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="mr-4 p-2 text-gray-600"
          >
            <X />
          </button>
          <h2 className="text-xl font-bold">Evidence Vault</h2>
          {!isOnline && (
            <div className="ml-2 px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">
              Offline - Will sync when online
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg p-4 mb-4">
          <input
            type="text"
            placeholder="Incident Title"
            value={newIncident.title}
            onChange={(e) => setNewIncident(prev => ({...prev, title: e.target.value}))}
            className="w-full p-3 border rounded mb-4"
          />
          
          <textarea
            placeholder="Describe what happened..."
            value={newIncident.description}
            onChange={(e) => setNewIncident(prev => ({...prev, description: e.target.value}))}
            className="w-full p-3 border rounded mb-4 h-32"
          />
          
          <input
            type="datetime-local"
            value={newIncident.date}
            onChange={(e) => setNewIncident(prev => ({...prev, date: e.target.value}))}
            className="w-full p-3 border rounded mb-4"
          />
          
          <select
            value={newIncident.severity}
            onChange={(e) => setNewIncident(prev => ({...prev, severity: e.target.value}))}
            className="w-full p-3 border rounded mb-4"
          >
            <option value="low">Low Severity</option>
            <option value="medium">Medium Severity</option>
            <option value="high">High Severity</option>
          </select>
          
          <div className="flex gap-2 mb-4">
            <button className="flex-1 p-3 border-2 border-dashed rounded flex items-center justify-center text-gray-500">
              <Camera className="mr-2" />
              Add Photo
            </button>
            <button className="flex-1 p-3 border-2 border-dashed rounded flex items-center justify-center text-gray-500">
              <Mic className="mr-2" />
              Add Audio
            </button>
          </div>
          
          <div className="flex items-center mb-4 text-sm text-gray-600">
            <Cloud className="mr-2" size={16} />
            {isOnline ? 'Auto-backup enabled' : 'Will backup when online'}
          </div>
          
          <button
            onClick={addIncident}
            className="w-full bg-purple-600 text-white p-3 rounded font-semibold"
          >
            Save to Evidence Vault
          </button>
        </div>

        {/* Previous Incidents */}
        <div className="space-y-3">
          {incidents.map(incident => (
            <div key={incident.id} className="bg-white rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold">{incident.title}</h3>
                <div className="flex items-center space-x-2">
                  {incident.autoBackup && <Cloud size={16} className="text-green-600" />}
                  <span className={`px-2 py-1 rounded text-xs ${
                    incident.severity === 'high' ? 'bg-red-100 text-red-800' :
                    incident.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {incident.severity}
                  </span>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-2">{incident.description}</p>
              <div className="flex justify-between items-center text-xs text-gray-400">
                <span>{new Date(incident.timestamp).toLocaleString()}</span>
                {incident.location && (
                  <span>📍 {incident.location.lat.toFixed(4)}, {incident.location.lng.toFixed(4)}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const Resources = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="mr-4 p-2 text-gray-600"
          >
            <X />
          </button>
          <h2 className="text-xl font-bold">Help & Resources</h2>
        </div>

        <div className="space-y-4">
          {/* Emergency Helplines */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Phone className="mr-2 text-red-500" />
              Emergency Helplines
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                <span>Women Helpline</span>
                <button className="font-mono text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  1091
                </button>
              </div>
              <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                <span>Domestic Violence</span>
                <button className="font-mono text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  181
                </button>
              </div>
              <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                <span>Emergency Services</span>
                <button className="font-mono text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  112
                </button>
              </div>
            </div>
          </div>

          {/* Legal Aid */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Scale className="mr-2 text-blue-500" />
              Legal Aid Services
            </h3>
            <div className="space-y-2">
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                Free Legal Consultation
              </button>
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                Know Your Rights
              </button>
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                File a Complaint Online
              </button>
            </div>
          </div>

          {/* Mental Health */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Heart className="mr-2 text-pink-500" />
              Mental Health Support
            </h3>
            <div className="space-y-2">
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                24/7 AI Counseling Chat
              </button>
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                Self-Help Resources
              </button>
              <button className="w-full text-left p-2 bg-gray-50 rounded hover:bg-gray-100">
                Find a Therapist Nearby
              </button>
            </div>
          </div>

          {/* Safety Tips */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Shield className="mr-2 text-green-500" />
              Safety Tips
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• Trust your instincts if something feels wrong</p>
              <p>• Keep emergency contacts easily accessible</p>
              <p>• Share your location with trusted friends regularly</p>
              <p>• Document incidents with photos and detailed notes</p>
              <p>• Create and practice a safety plan for emergencies</p>
              <p>• Use the disguised interface when in danger</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const Community = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="mr-4 p-2 text-gray-600"
          >
            <X />
          </button>
          <h2 className="text-xl font-bold">Community Support</h2>
        </div>

        <div className="space-y-4">
          {/* Support Groups */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3">Anonymous Support Groups</h3>
            <div className="space-y-3">
              <div className="p-3 border-l-4 border-purple-500 bg-purple-50">
                <p className="font-semibold">Survivors Circle</p>
                <p className="text-sm text-gray-600">Safe space for sharing experiences</p>
                <p className="text-xs text-purple-600">24 members online</p>
              </div>
              <div className="p-3 border-l-4 border-blue-500 bg-blue-50">
                <p className="font-semibold">Recovery Journey</p>
                <p className="text-sm text-gray-600">Healing and moving forward together</p>
                <p className="text-xs text-blue-600">18 members online</p>
              </div>
              <div className="p-3 border-l-4 border-green-500 bg-green-50">
                <p className="font-semibold">Legal Support Network</p>
                <p className="text-sm text-gray-600">Legal advice and court support</p>
                <p className="text-xs text-green-600">12 members online</p>
              </div>
            </div>
          </div>

          {/* Anonymous Chat */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3">Anonymous Chat</h3>
            <div className="bg-gray-100 p-3 rounded mb-3 h-40 overflow-y-auto">
              <div className="space-y-2 text-sm">
                <p><strong>Anonymous1:</strong> Feeling stronger every day. Thank you all for the support. 💪</p>
                <p><strong>Helper23:</strong> Remember, you are not alone. We're here for you. ❤️</p>
                <p><strong>Anonymous2:</strong> Does anyone know about legal aid in Delhi?</p>
                <p><strong>Volunteer:</strong> @Anonymous2 I can help with that. Check the resources section.</p>
                <p><strong>Anonymous3:</strong> The app's AI detection helped me last week. Stay safe everyone!</p>
              </div>
            </div>
            <div className="flex">
              <input
                type="text"
                placeholder="Type a message... (Anonymous)"
                className="flex-1 p-2 border rounded-l"
              />
              <button className="bg-purple-600 text-white p-2 rounded-r">
                <Send size={18} />
              </button>
            </div>
          </div>

          {/* Local Volunteer Network */}
          <div className="bg-white rounded-lg p-4">
            <h3 className="font-bold text-lg mb-3">Local Volunteer Network</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                <div>
                  <p className="font-semibold text-sm">Safe Transport</p>
                  <p className="text-xs text-gray-600">Available 24/7 in your area</p>
                </div>
                <button className="bg-green-500 text-white px-3 py-1 rounded text-sm">
                  Request
                </button>
              </div>
              <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                <div>
                  <p className="font-semibold text-sm">Emergency Shelter</p>
                  <p className="text-xs text-gray-600">Safe house - 2 km away</p>
                </div>
                <button className="bg-blue-500 text-white px-3 py-1 rounded text-sm">
                  Contact
                </button>
              </div>
              <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                <div>
                  <p className="font-semibold text-sm">Legal Advocate</p>
                  <p className="text-xs text-gray-600">Free consultation available</p>
                </div>
                <button className="bg-yellow-500 text-white px-3 py-1 rounded text-sm">
                  Connect
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Render current view based on authentication and disguise mode
  const renderCurrentView = () => {
    if (!isAuthenticated) {
      switch (disguiseMode) {
        case 'gallery':
          return <DisguisedGallery />;
        case 'notes':
          return <DisguisedNotes />;
        default:
          return <DisguisedCalculator />;
      }
    }

    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'incidents':
        return <IncidentLogger />;
      case 'contacts':
        return <TrustedContacts />;
      case 'settings':
        return <SafetySettings />;
      case 'resources':
        return <Resources />;
      case 'community':
        return <Community />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="font-sans relative">
      {renderCurrentView()}
      
      {/* Pin Input Modal */}
      {showPinInput && <PinInput />}
      
      {/* Fake Call Overlay */}
      {fakeCallActive && <FakeCallScreen />}
      
      {/* Menu Overlay */}
      {showMenu && isAuthenticated && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setShowMenu(false)}>
          <div className="absolute top-4 right-4 bg-white rounded-lg p-4 w-56">
            <div className="space-y-2">
              <button
                onClick={() => {
                  panicExit();
                  setShowMenu(false);
                }}
                className="w-full text-left p-2 hover:bg-red-50 rounded flex items-center text-red-600"
              >
                <Lock className="mr-2" size={16} />
                Panic Exit (Hide App)
              </button>
              <button
                onClick={() => {
                  setCurrentView('settings');
                  setShowMenu(false);
                }}
                className="w-full text-left p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <Settings className="mr-2" size={16} />
                Safety Plan Settings
              </button>
              <button
                onClick={() => {
                  setCurrentView('contacts');
                  setShowMenu(false);
                }}
                className="w-full text-left p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <UserPlus className="mr-2" size={16} />
                Manage Contacts
              </button>
              <hr />
              <div className="text-xs text-gray-500 p-2">
                <p>Double-click anywhere to panic exit</p>
                <p>Current status: {isOnline ? 'Online' : 'Offline'}</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Network Status Indicator */}
      {!isOnline && (
        <div className="fixed bottom-4 left-4 bg-yellow-500 text-white px-3 py-1 rounded-full text-sm flex items-center">
          <WifiOff size={16} className="mr-1" />
          Offline Mode
        </div>
      )}
    </div>
  );
};

export default SAHAYAK;