import React from 'react'
import SAHAYAK from './sahayak-app'

export default function App() {
  return (
    <div className='min-h-screen'>
      <SAHAYAK />
    </div>
  )
}
